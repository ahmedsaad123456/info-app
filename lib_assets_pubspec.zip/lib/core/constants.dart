import 'package:info_app/features/login_screen/data/models/code_model.dart';

const BASE_URL = 'https://api.neurosubconscious.ru/api';

late String? token;