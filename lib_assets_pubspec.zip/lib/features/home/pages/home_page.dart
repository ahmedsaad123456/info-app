import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:info_app/features/courses/course_state_enum.dart';
import 'package:info_app/features/home/widgets/browse_widget.dart';
import 'package:info_app/features/home/widgets/course_by_category.dart';
import 'package:info_app/features/home/widgets/course_owner_widget.dart';
import 'package:info_app/features/home/widgets/courses_list_view.dart';
import 'package:info_app/features/home/widgets/story_list_view.dart';
import 'package:info_app/widget/custom_button.dart';

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            SvgPicture.asset(
              'assets/icons/logo.svg',
              fit: BoxFit.fitWidth,
            ),
          ],
        ),
        const Padding(
          padding: EdgeInsets.symmetric(vertical: 32),
          child: StoryListView(),
        ),
        Image.asset('assets/icons/home3.png'),
        const SizedBox(
          height: 32,
        ),
        Text(
          textAlign: TextAlign.center,
          'Более 500 тысяч человек смогли изменить свою жизнь через работу с подсознанием по уникальной методике Инны ТИ. Благодаря работе с подсознанием, можно быстро и легко изменить все сферы жизни. На платформе вы найдёте более 100 методик. Подписка открывает доступ к огромной базе курсов, семинаров и тренажёров для работы с подсознанием',
          style: TextStyle(
              fontWeight: FontWeight.w400,
              fontSize: 16,
              color: Colors.white.withOpacity(0.64)),
        ),
        const SizedBox(
          height: 10,
        ),
        const Center(
          child: ButtonWidget(
              text: 'Оформить подписку',
              height: 52,
              width: 350,
              color: Color(0xFFF8206E),
              textColor: Colors.white),
        ),
        const SizedBox(
          height: 32,
        ),
        const BrowseWidget(),
        const SizedBox(
          height: 32,
        ),
        const CoursesListView(
          title: 'Демо курсы',
          subtitle:
              'Авторские курсы, которые доступны всем пользователям нашего приложения',
          courseStateEnum: CourseStateEnum.PURCHASED,
        ),
        const SizedBox(
          height: 32,
        ),
        const CoursesListView(
          title: 'Подписка Нейро',
          subtitle:
              'Авторские курсы, которые доступны только по подписке Нейро и выше',
          courseStateEnum: CourseStateEnum.NOT_PURCHASED,
          isNotPlus: true,
        ),
        const SizedBox(
          height: 32,
        ),
        const CoursesListView(
            title: 'Подписка Нейро+',
            subtitle:
                'Авторские курсы, которые доступны только по подписке Нейро+',
            courseStateEnum: CourseStateEnum.NOT_PURCHASED),
        const SizedBox(
          height: 32,
        ),
        const CourseOwnerWidget(),
        const SizedBox(
          height: 32,
        ),
        const Align(
          alignment: AlignmentDirectional.bottomStart,
          child: Text(
            'Курсы по категориям',
            style: TextStyle(
                color: Colors.white,
                fontSize: 28,
                fontWeight: FontWeight.w500),
          ),
        ),
        const SizedBox(
          height: 15,
        ),
        const CourseByCategory(
          title: 'Отношения',
          courseStateEnum: CourseStateEnum.VIEWED,
          titleContainer: 'Нейро',
          isBookmark: true,
        ),
        const SizedBox(
          height: 15,
        ),
        const CourseByCategory(
          title: 'Здоровье',
          courseStateEnum: CourseStateEnum.NOT_PURCHASED,
          isBookmark: false,
          isNotPlus: false,
        ),
        const SizedBox(
          height: 15,
        ),
        const CourseByCategory(
          title: 'Финансы',
          courseStateEnum: CourseStateEnum.VIEWED,
          titleContainer: 'Просмотрено',
          isBookmark: false,
        ),
        const SizedBox(
          height: 15,
        ),
        const CourseByCategory(
          title: 'Отношения',
          courseStateEnum: CourseStateEnum.NOT_PURCHASED,
          isBookmark: false,
          isNotPlus: true,
        ),
      ],
    );
  }
}
