import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:info_app/features/home/cubit/home_satate.dart';
import 'package:info_app/features/home/pages/home_page.dart';
import 'package:info_app/features/profile/presentation/cubit/profile_cubit.dart';
import 'package:info_app/features/profile/presentation/pages/profile_page.dart';
import 'package:info_app/features/search/search_page.dart';

class HomeCubit extends Cubit<HomeStates> {
  HomeCubit() : super(HomeInitialState());
  static HomeCubit get(context) => BlocProvider.of(context);

  List<Widget> screens = [
    const SearchPage(),
    const HomePage(),
    ProfilePage(),
  ];

  int index = 1;

  void changeIndex(int newIndex, BuildContext context) async {
    index = newIndex;
    if (index == 2) {
      await ProfileCubit.get(context).getCodeModel();
    }
    emit(HomeBottomNavState());
  }

  Color getIconColor(int itemIndex) {
    return index == itemIndex ? Color(0xFFF8206E) : Colors.white.withOpacity(0.64);
  }
}
