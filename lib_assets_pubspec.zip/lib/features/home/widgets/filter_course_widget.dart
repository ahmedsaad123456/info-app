import 'package:flutter/material.dart';
import 'package:info_app/features/courses/widgets/title_widget.dart';
import 'package:info_app/widget/custom_button.dart';

class FilterCourseWidget extends StatelessWidget {
  const FilterCourseWidget(
      {super.key, required this.title, required this.subtitle});

  final String title, subtitle;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        TitleWidget(title: title, subtitle: subtitle),
        const SizedBox(
          height: 10,
        ),
        Wrap(
          spacing: 8.0,
          runSpacing: 8.0,
          children: [
            IntrinsicWidth(child: ToggleButtonWidget(text: 'Здоровье')),
            IntrinsicWidth(child: ToggleButtonWidget(text: 'Финансы')),
            IntrinsicWidth(child: ToggleButtonWidget(text: 'Отношения')),
            IntrinsicWidth(child: ToggleButtonWidget(text: 'Предназначение')),
            IntrinsicWidth(child: ToggleButtonWidget(text: 'Сексуальность')),
          ],
        ),
      ],
    );
  }
}

class ToggleButtonWidget extends StatefulWidget {
  final String text;

  const ToggleButtonWidget({super.key, required this.text});

  @override
  _ToggleButtonWidgetState createState() => _ToggleButtonWidgetState();
}

class _ToggleButtonWidgetState extends State<ToggleButtonWidget> {
  bool isSelected = false;

  void toggleButton() {
    setState(() {
      isSelected = !isSelected;
    });
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: toggleButton,
      child: ButtonWidget(
        padding: 10,
        text: widget.text,
        height: 43,
        color: isSelected ? Colors.white : Colors.white.withOpacity(0.08),
        textColor: isSelected ? Colors.black : Colors.white.withOpacity(0.64),
        boxBorder: !isSelected  ? Border.all(width: 2, color: Colors.white.withOpacity(0.08)) : null,
      ),
    );
  }
}
