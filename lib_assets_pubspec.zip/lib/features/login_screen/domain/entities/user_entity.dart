class UserEntity {
  bool? result;
  int? code;
  int? account_id;


   UserEntity({
    this.result,
    this.code,
    this.account_id

  });
}