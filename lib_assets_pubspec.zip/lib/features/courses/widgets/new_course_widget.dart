import 'package:flutter/material.dart';
import 'package:info_app/features/courses/widgets/buy_row.dart';
import 'package:info_app/features/courses/course_state_enum.dart';
import 'package:info_app/features/courses/widgets/recommended_container.dart';

class NewCourseWidget extends StatefulWidget {
  const NewCourseWidget({
    super.key,
    required this.courseStateEnum,
    this.isNotPlus,
    required this.isBookmark,
    this.title,
    required this.isHistory,
  });

  final bool? isNotPlus;
  final bool isBookmark;
  final String? title;
  final bool isHistory;
  final CourseStateEnum courseStateEnum;

  @override
  _NewCourseWidgetState createState() => _NewCourseWidgetState();
}

class _NewCourseWidgetState extends State<NewCourseWidget> {
  late bool isBookmarked;

  @override
  void initState() {
    super.initState();
    isBookmarked = widget.isBookmark;
  }

  void toggleBookmark() {
    setState(() {
      isBookmarked = !isBookmarked;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        Container(
          decoration: ShapeDecoration(
              gradient: widget.courseStateEnum == CourseStateEnum.NOT_PURCHASED
                  ? const LinearGradient(
                      begin: Alignment.centerRight,
                      end: Alignment.centerLeft,
                      colors: [
                        Color.fromRGBO(255, 136, 136, 1),
                        Color.fromRGBO(255, 55, 151, 1),
                      ],
                    )
                  : null,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8),
                  side: BorderSide(
                      width: 1, color: Colors.white.withOpacity(0.08)))),
          height: 200,
          child: SizedBox(
            width: widget.isHistory ? double.infinity : 350,
            child: Image.asset(
              'assets/icons/course.png',
              fit: BoxFit.cover,
            ),
          ),
        ),
        Positioned(
          bottom: 20,
          left: 20,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Новый курс',
                style: TextStyle(
                    fontSize: 28,
                    color: Colors.white,
                    fontWeight: FontWeight.w500),
              ),
              Text(
                'Трансфармационный марафон \n20 серий / 361 минута',
                style: TextStyle(
                    fontSize: 16,
                    color: Colors.white.withOpacity(
                      0.64,
                    ),
                    fontWeight: FontWeight.w400),
              ),
            ],
          ),
        ),
        Positioned(
          top: 20,
          right: 25,
          child: GestureDetector(
            onTap: toggleBookmark,
            child: SizedBox(
              height: 24,
              width: 24,
              child: FittedBox(
                child: Icon(
                  isBookmarked
                      ? Icons.bookmark
                      : Icons.bookmark_border_outlined,
                  color: isBookmarked
                      ? const Color(0xFFF8206E)
                      : Colors.white.withOpacity(0.64),
                ),
              ),
            ),
          ),
        ),
        widget.courseStateEnum == CourseStateEnum.NOT_PURCHASED
            ? Positioned(
                top: 20,
                left: 25,
                child: BuyRow(
                  isNotPlus: widget.isNotPlus,
                ),
              )
            : widget.courseStateEnum == CourseStateEnum.VIEWED
                ? Positioned(
                    top: 20,
                    left: 25,
                    child: RecommendedContainer(
                      title: widget.title ?? '',
                    ),
                  )
                : const SizedBox(),
      ],
    );
  }
}
