enum CourseStateEnum {
  VIEWED,
  PURCHASED,
  NOT_PURCHASED,
}