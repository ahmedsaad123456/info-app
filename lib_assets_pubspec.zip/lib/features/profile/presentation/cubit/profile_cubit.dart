import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:info_app/core/constants.dart';
import 'package:info_app/core/shared/datasources/local/cache_helper.dart';
import 'package:info_app/features/login_screen/data/models/code_model.dart';

import 'package:info_app/features/profile/domain/usecases/profile_usecase.dart';
import 'package:info_app/features/profile/presentation/cubit/profile_state.dart';
import 'package:info_app/locator.dart';

class ProfileCubit extends Cubit<ProfileState> {
  ProfileCubit(this._profileUsecase) : super(ProfileInitialState());

  TextEditingController phoneController = TextEditingController();
  TextEditingController emailController = TextEditingController();

  final _cacheHelper = locator<CacheHelper>();
  final ProfileUsecase _profileUsecase;

  static ProfileCubit get(context) => BlocProvider.of(context);

  CodeModel? codeModel;

  Future<void> getCodeModel() async {
    codeModel ??= await _cacheHelper.getUser();
    print(codeModel?.account?.toJson() ?? 'okkkkkkkkkkk');
    phoneController.text = codeModel?.account?.phone ?? '+7';
    emailController.text = codeModel?.account?.email ?? '';
  }

  Future<void> updateProfile() async {
    emit(ProfileUpdateLoadingState());
    final result = await _profileUsecase.updateProfile(
        codeModel?.account?.name ?? '',
        emailController.text,
        phoneController.text);
    result.fold(
      (l) {
        emit(ProfileUpdateErrorState(error: l));
      },
      (r) {
        phoneController.clear();
        emailController.clear();
        codeModel = r;
        codeModel!.token = token;
        _cacheHelper.saveUser(r);
        emit(ProfileUpdateSuccessState());
      },
    );
  }

  void signOut() async {
    await _cacheHelper.removeUser();
    await _cacheHelper.removeData(key: 'token');
  }
}
