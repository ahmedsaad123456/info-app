class PreferencesNames {
  static const String isLogin = "isLogin";

}